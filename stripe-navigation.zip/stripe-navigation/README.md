Stripe.Com Navigation
=========

A morphing dropdown that animates according to the size of its content.

[Article on CodyHouse](http://codyhouse.co/gem/stripe-navigation/)

[Demo](http://codyhouse.co/demo/stripe-navigation/index.html)
 
[Terms](http://codyhouse.co/terms/)

Original version: [Stripe.com](https://stripe.com/)

Icons: [Nucleoapp.com](http://nucleoapp.com/)